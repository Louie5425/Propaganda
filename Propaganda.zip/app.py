import os, subprocess, threading, time, webbrowser, base64, traceback
from flask import Flask, request, session, redirect, Response
from pymongo import MongoClient
from bson import ObjectId

app = Flask(__name__)
app.secret_key = 'propaganda-secret-key-oldstyle'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max
PORT = 3000

# ==================== MONGODB (lazy connect) ====================
_client = None
_db = None
_tasks = None

def get_tasks_col():
    global _client, _db, _tasks
    if _tasks is None:
        _client = MongoClient('mongodb+srv://admin:dGlSd1hICNRaLMSp@thehugeapp.i5yaor6.mongodb.net/propaganda?appName=TheHugeApp', serverSelectionTimeoutMS=5000)
        _db = _client['propaganda']
        _tasks = _db['tasks']
    return _tasks

# ==================== SETUP ====================
USERS = [
    {'username': 'admin', 'password': 'admin', 'role': 'admin'},
    {'username': 'Louie', 'password': 'uvl]x-bntw@_kvh~', 'role': 'user'}
]

def require_login(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user' not in session: return redirect('/')
        return f(*args, **kwargs)
    return decorated

def require_admin(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user' not in session or session['user']['role'] != 'admin': return redirect('/')
        return f(*args, **kwargs)
    return decorated

# ==================== TEMPLATES ====================
LOGIN_HTML = '''<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>Propaganda - Login</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%%;background:#c0c0c0;font-family:"Times New Roman",serif;font-size:14px;overflow:hidden}
body{display:flex;flex-direction:column}
.header{background:#000080;padding:6px 10px;text-align:center}
.login-body{flex:1;background:#d4d0c8;display:flex;flex-direction:column;align-items:center;justify-content:center;border:2px inset #808080}
td{padding:4px 6px}
input[type="text"],input[type="password"]{font-family:"Times New Roman",serif;font-size:14px;border:2px inset #808080;background:#fff;padding:2px 4px;width:180px}
input[type="submit"]{font-family:"Times New Roman",serif;font-size:14px;border:2px outset #808080;background:#c0c0c0;padding:2px 16px;cursor:pointer}
input[type="submit"]:active{border-style:inset}
.error-text{color:red;font-weight:bold}
.footer{background:#c0c0c0;border-top:1px solid #808080;padding:3px;text-align:center}
</style></head><body>
<div class="header"><font color="#fff" size="4"><b>&#9632; System Login &#9632;</b></font></div>
<div class="login-body">
%s
<form method="POST" action="/login"><table border="0" cellpadding="4">
<tr><td align="right"><b>Username:</b></td><td><input type="text" name="username" size="20"></td></tr>
<tr><td align="right"><b>Password:</b></td><td><input type="password" name="password" size="20"></td></tr>
<tr><td colspan="2" align="center"><br><input type="submit" value="  Log In  "></td></tr>
</table></form><br><font size="1" color="#808080">Authorized personnel only.</font>
</div><div class="footer"><font size="1" color="#808080">System v1.0</font></div>
</body></html>'''

LOADING_HTML = '''<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>Propaganda - Loading</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%%;background:#000;font-family:"Courier New",monospace;font-size:13px;color:#0f0;overflow:hidden}
body{display:flex;flex-direction:column}
.terminal{flex:1;padding:10px;overflow:hidden}
.line{opacity:0;white-space:pre;line-height:1.5}
.line.visible{opacity:1}
.line.ok{color:#0f0}.line.warn{color:#ff0}.line.info{color:#808080}.line.header{color:#0cf;font-weight:bold}
.progress-bar-container{margin:4px 0;opacity:0}.progress-bar-container.visible{opacity:1}
.progress-bar{width:0%%;height:14px;background:#0a0;border:1px solid #0f0;transition:width 0.1s linear}
.progress-label{color:#808080;font-size:11px}
.cursor-blink{animation:blink .5s infinite}
@keyframes blink{0%%,50%%{opacity:1}51%%,100%%{opacity:0}}
</style></head><body>
<div class="terminal">
<div class="line header" id="l0">========================================</div>
<div class="line header" id="l1">  PROPAGANDA SYSTEM v1.0 - INITIALIZING</div>
<div class="line header" id="l2">========================================</div>
<div class="line info" id="l3">User: %s | Access Level: %s</div>
<div class="line" id="l4"></div>
<div class="line ok" id="l5">[SYS] Connecting to secure server........... OK</div>
<div class="line ok" id="l6">[SYS] Verifying credentials................. OK</div>
<div class="line warn" id="l7">[SEC] Encrypting session channel............ DONE</div>
<div class="line ok" id="l8">[SYS] Loading user permissions.............. OK</div>
<div class="line ok" id="l9">[DB ] Syncing task database................. OK</div>
<div class="line info" id="l10">[DB ] Found %d task(s) in database</div>
<div class="line ok" id="l11">[SYS] Loading file index.................... OK</div>
<div class="line warn" id="l12">[SEC] Checking firewall status.............. ACTIVE</div>
<div class="line ok" id="l13">[NET] Establishing P2P tunnel............... OK</div>
<div class="line ok" id="l14">[SYS] Initializing interface modules........ OK</div>
<div class="line" id="l15"></div>
<div class="line info" id="l16">Loading system resources:</div>
<div class="progress-bar-container" id="pbar"><div class="progress-bar" id="progress"></div></div>
<div class="line progress-label" id="l17">0%%</div>
<div class="line" id="l18"></div>
<div class="line ok" id="l19">[SYS] System ready. Launching interface...<span class="cursor-blink">_</span></div>
</div>
<script>
var redirect='%s';var lines=document.querySelectorAll('.line');var pbar=document.getElementById('pbar');
var progress=document.getElementById('progress');var progressLabel=document.getElementById('l17');var currentLine=0;var totalLines=lines.length;
function showLine(){if(currentLine>=totalLines)return;var line=lines[currentLine];var id=line.id;
if(id==='l16'){line.classList.add('visible');currentLine++;setTimeout(function(){pbar.classList.add('visible');animateProgress(0);},200);return;}
if(id==='l17'||id==='pbar'){currentLine++;showLine();return;}
if(id==='l19'){line.classList.add('visible');setTimeout(function(){window.location.href=redirect;},1200);return;}
line.classList.add('visible');currentLine++;var delay=150+Math.random()*300;
if(id==='l4'||id==='l15'||id==='l18')delay=100;if(id==='l5'||id==='l9'||id==='l13')delay=400+Math.random()*500;
setTimeout(showLine,delay);}
function animateProgress(pct){if(pct>100){progressLabel.textContent='100%% - Complete';progressLabel.classList.add('visible');
currentLine=totalLines-2;setTimeout(function(){lines[currentLine].classList.add('visible');currentLine++;setTimeout(showLine,300);},300);return;}
progress.style.width=pct+'%%';progressLabel.textContent=pct+'%%';progressLabel.classList.add('visible');
var step=Math.floor(Math.random()*8)+1;var delay=30+Math.random()*80;
if(pct>40&&pct<55)delay=100+Math.random()*150;if(pct>80)delay=20+Math.random()*40;
setTimeout(function(){animateProgress(pct+step);},delay);}
setTimeout(showLine,500);
</script></body></html>'''

def file_html(file, idx, task_id):
    name = file.get('originalName','file')
    m = file.get('mimetype','')
    url = f'/file/{task_id}/{idx}'
    if m.startswith('image/'):
        return f'<a href="{url}" target="_blank">{name}</a><br><img src="{url}" width="200" border="1">'
    elif m.startswith('video/'):
        return f'<a href="{url}" target="_blank">{name}</a><br><video width="300" controls><source src="{url}" type="{m}"></video>'
    elif m.startswith('audio/'):
        return f'<a href="{url}" target="_blank">{name}</a><br><audio controls><source src="{url}" type="{m}"></audio>'
    else:
        sz = file.get('size',0)/1024
        return f'&#128196; <a href="{url}" target="_blank" download="{name}">{name}</a> <font size="1" color="#808080">({sz:.1f} KB)</font>'

def task_html(task, admin=False):
    tid = str(task['_id'])
    h = '<div class="task-box">'
    if admin:
        h += f'<table width="100%" border="0"><tr><td><font size="3"><b>&#9654; {task["title"]}</b></font></td>'
        h += f'<td align="right"><form method="POST" action="/admin/delete-task/{tid}" style="display:inline" onsubmit="return confirm(\'Delete?\')"><button type="submit" class="delete-btn">[X] Delete</button></form></td></tr></table>'
    else:
        h += f'<font size="3"><b>&#9654; {task["title"]}</b></font><br>'
    h += '<hr size="1">'
    if task.get('description'):
        h += f'<pre style="white-space:pre-wrap;font-family:\'Times New Roman\',serif;margin:4px 0">{task["description"]}</pre>'
    files = task.get('files', [])
    if files:
        h += '<hr size="1"><font size="2"><b>Attachments:</b></font><br><ul>'
        for i, f in enumerate(files):
            h += '<li>' + file_html(f, i, tid) + '</li>'
        h += '</ul>'
    h += '</div>'
    return h

ADMIN_STYLE = '''*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%;background:#c0c0c0;font-family:"Times New Roman",serif;font-size:14px}
body{display:flex;flex-direction:column}
.toolbar{background:#d4d0c8;border-bottom:1px solid #808080;padding:3px 8px;display:flex;justify-content:space-between;align-items:center}
.content{flex:1;overflow-y:auto;padding:8px}table{border-collapse:collapse}
input[type="text"],textarea{font-family:"Times New Roman",serif;font-size:14px;border:2px inset #808080;background:#fff;padding:1px 2px}
input[type="file"]{font-family:"Times New Roman",serif;font-size:12px}
input[type="submit"],.btn{font-family:"Times New Roman",serif;font-size:14px;border:2px outset #808080;background:#c0c0c0;padding:1px 8px;cursor:pointer;text-decoration:none;color:#000}
input[type="submit"]:active,.btn:active{border-style:inset}
a{color:#00f}a:visited{color:#800080}
.task-box{border:2px inset #808080;background:#fff;padding:8px;margin-bottom:8px}
.delete-btn{font-family:"Times New Roman",serif;font-size:12px;border:2px outset #808080;background:#c0c0c0;padding:0 6px;cursor:pointer;color:red}
.delete-btn:active{border-style:inset}
.status-bar{background:#d4d0c8;border-top:1px solid #808080;padding:2px 8px;font-size:11px;color:#808080}'''

# ==================== ROUTES ====================
@app.route('/')
def index():
    if 'user' in session:
        return redirect('/admin' if session['user']['role'] == 'admin' else '/tasks')
    return LOGIN_HTML % ''

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username','')
    password = request.form.get('password','')
    user = next((u for u in USERS if u['username']==username and u['password']==password), None)
    if user:
        session['user'] = {'username': user['username'], 'role': user['role']}
        return redirect('/loading')
    return LOGIN_HTML % '<p class="error-text">&#9888; Invalid username or password!</p><hr size="1" width="80%"><br>'

@app.route('/loading')
@require_login
def loading():
    u = session['user']
    count = get_tasks_col().count_documents({})
    redir = '/admin' if u['role'] == 'admin' else '/tasks'
    level = 'ADMINISTRATOR' if u['role'] == 'admin' else 'STANDARD'
    return LOADING_HTML % (u['username'], level, count, redir)

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route('/admin')
@require_admin
def admin():
    tasks = list(get_tasks_col().find().sort('_id', -1))
    tasks_html = ''.join(task_html(t, admin=True) for t in tasks)
    if not tasks:
        tasks_html = '<center><font color="#808080"><i>No tasks yet.</i></font></center>'
    return f'''<!DOCTYPE HTML><html><head><title>Propaganda - Admin</title><style>{ADMIN_STYLE}</style></head><body>
<div class="toolbar"><span><b>&#9776; Admin Panel</b> | Logged in as: <b>{session["user"]["username"]}</b></span><a href="/logout" class="btn">Logout</a></div>
<div class="content">
<table border="1" cellpadding="8" cellspacing="0" bgcolor="#d4d0c8" width="100%">
<tr><td bgcolor="#808080" align="center"><font color="#fff" size="3"><b>&#9998; Create New Task</b></font></td></tr>
<tr><td><form method="POST" action="/admin/create-task" enctype="multipart/form-data">
<table border="0" cellpadding="4" width="100%">
<tr><td align="right" width="100"><b>Title:</b></td><td><input type="text" name="title" style="width:100%" required></td></tr>
<tr><td align="right" valign="top"><b>Description:</b></td><td><textarea name="description" rows="4" style="width:100%"></textarea></td></tr>
<tr><td align="right" valign="top"><b>Attachments:</b></td><td><input type="file" name="files" multiple><br><font size="1" color="#808080">(max 10MB per file)</font></td></tr>
<tr><td colspan="2" align="center"><input type="submit" value="  Create Task  "></td></tr>
</table></form></td></tr></table>
<br><font size="3"><b>&#9776; Existing Tasks ({len(tasks)})</b></font><hr size="1">
{tasks_html}</div>
<div class="status-bar">Tasks: {len(tasks)} | Admin Panel v1.0</div></body></html>'''

@app.route('/admin/create-task', methods=['POST'])
@require_admin
def create_task():
    try:
        title = request.form.get('title', 'No Title')
        description = request.form.get('description', '')
        files_data = []
        for f in request.files.getlist('files'):
            if f.filename:
                data = f.read()
                b64 = base64.b64encode(data).decode('ascii')
                files_data.append({
                    'originalName': f.filename,
                    'data': b64,
                    'mimetype': f.content_type or 'application/octet-stream',
                    'size': len(data)
                })
        get_tasks_col().insert_one({
            'title': title,
            'description': description,
            'files': files_data,
            'createdBy': session['user']['username']
        })
        return redirect('/admin')
    except Exception as e:
        err = traceback.format_exc()
        print('CREATE TASK ERROR:', err)
        return f'<pre>Error:\n{err}</pre>', 500

@app.route('/admin/delete-task/<task_id>', methods=['POST'])
@require_admin
def delete_task(task_id):
    get_tasks_col().delete_one({'_id': ObjectId(task_id)})
    return redirect('/admin')

@app.route('/tasks')
@require_login
def tasks_view():
    tasks = list(get_tasks_col().find().sort('_id', -1))
    tasks_html = ''.join(task_html(t) for t in tasks)
    if not tasks:
        tasks_html = '<center><font color="#808080"><i>No tasks available.</i></font></center>'
    style = ADMIN_STYLE.replace('.delete-btn{','._x{')
    return f'''<!DOCTYPE HTML><html><head><title>Propaganda - Tasks</title><style>{style}</style></head><body>
<div class="toolbar"><span><b>&#9776; Task Board</b> | Logged in as: <b>{session["user"]["username"]}</b></span><a href="/logout" class="btn">Logout</a></div>
<div class="content">
<font size="3"><b>&#9776; Assigned Tasks ({len(tasks)})</b></font><hr size="1">
{tasks_html}</div>
<div class="status-bar">Tasks: {len(tasks)} | Task Viewer v1.0</div></body></html>'''

@app.route('/file/<task_id>/<int:idx>')
@require_login
def serve_file(task_id, idx):
    try:
        task = get_tasks_col().find_one({'_id': ObjectId(task_id)})
        if task and idx < len(task.get('files', [])):
            f = task['files'][idx]
            data = base64.b64decode(f['data'])
            return Response(data, mimetype=f.get('mimetype','application/octet-stream'),
                           headers={'Content-Disposition': f'inline; filename="{f["originalName"]}"'})
        return 'File not found', 404
    except:
        return 'File not found', 404

# ==================== START ====================
def open_browser():
    time.sleep(0.5)
    url = f'http://localhost:{PORT}'
    flags = f'--app={url} --window-size=500,420 --disable-save-password-bubble --disable-infobars --guest --no-first-run'
    try:
        subprocess.Popen(f'start msedge {flags}', shell=True)
    except:
        try:
            subprocess.Popen(f'start chrome {flags}', shell=True)
        except:
            webbrowser.open(url)

if __name__ == '__main__':
    threading.Thread(target=open_browser, daemon=True).start()
    app.run(port=PORT, debug=False)
